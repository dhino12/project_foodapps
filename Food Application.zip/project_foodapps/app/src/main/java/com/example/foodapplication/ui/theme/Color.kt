package com.example.foodapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Orange200 = Color(0xFFFF7700)
val Red200 = Color(0xFFF53783)
val Navy200 = Color(0xFFC3DFED)
val Navy500 = Color(0xFF2D3E50)
val White100 = Color(0xFFFFFFFF)
val Navy700 = Color(0xFF152439)
val Turquoise500 = Color(0xFF11C5C6)
